$(document).ready(function() {

  
  $('a').click(function (event) 
{ 
     event.preventDefault(); 
     //here you can also do all sort of things 
});
  
  $('#jamz-download').click(function(e) {
    e.preventDefault();  //stop the browser from following
    window.location.href = 'uploads/file.doc';
});
  
    $('#imagine-download').click(function(e) {
    e.preventDefault();  //stop the browser from following
    window.location.href = 'uploads/file.doc';
});

  
  $('#git-button').click(function() {
    
      window.open('https://github.com/MichaelPopeDeveloper?tab=repositories', '_blank');
    
  });
  
    $('#blog-button').click(function() {
    
      window.open('https://easydev.blog/', '_blank');
    
  });
   

  
  $(window).resize(function() {
  //update stuff

  if ($(window).width() < 913) {
    
    $(window).scrollTop(0);

}
else {
    
}
  
  });
});